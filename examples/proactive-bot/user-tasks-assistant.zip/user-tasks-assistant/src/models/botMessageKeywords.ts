export enum BotMessageKeywords {
  chatDocument = "/chatDocument",
  chatGPT = "/chatGPT",
  document = "/document",
  debug = "/debug",
  forget = "/forget",
  history = "/history",
  newchat = "/newchat",
  welcome = "/welcome",
  resetIndex = "/resetIndex",
}
