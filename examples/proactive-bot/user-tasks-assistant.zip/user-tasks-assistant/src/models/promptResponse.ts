export interface PromptResponse {
  response: string;
}
