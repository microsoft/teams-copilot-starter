export interface User {
  id?: string;
  aadObjectId?: string;
  name?: string;
  email?: string;
  userPrincipalName?: string;
  token?: string;
  source?: string;
}
