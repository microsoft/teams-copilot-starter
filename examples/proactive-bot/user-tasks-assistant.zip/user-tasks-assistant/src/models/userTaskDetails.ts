export interface UserTaskDetails {
  id: string;
  description: string;
  referenceName?: string;
  referenceUri?: string;
}
