export interface CardSubmitData {
  verb: string;
  id: string;
  companyName: string;
}
