export enum AIPrompts {
  ChatGPT = "chatGPT",
  SummarizeDocument = "summarizeDocument",
  QuestionDocument = "questionDocument",
  QuestionWeb = "questionWeb",
}
