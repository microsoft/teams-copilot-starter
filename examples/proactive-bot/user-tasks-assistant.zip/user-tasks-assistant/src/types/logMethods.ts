export enum LogMethods {
  Log = "log",
  TrackEvent = "trackEvent",
  TrackMetric = "trackMetric",
}
