export { suggestedPrompt } from "./suggestedPrompt";
